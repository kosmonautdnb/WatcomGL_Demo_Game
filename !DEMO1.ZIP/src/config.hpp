#ifndef __CONFIG_HPP__
#define __CONFIG_HPP__

#define USE_SPRITES true

#endif //__CONFIG_HPP__
