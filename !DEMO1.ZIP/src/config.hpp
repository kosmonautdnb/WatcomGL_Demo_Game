#ifndef __CONFIG_HPP__
#define __CONFIG_HPP__

#define USE_SPRITES false

#endif //__CONFIG_HPP__
