#ifndef __CAMERA_HPP__
#define __CAMERA_HPP__

void setCameraBackground();
void setCameraGame();

#endif //__CAMERA_HPP__
