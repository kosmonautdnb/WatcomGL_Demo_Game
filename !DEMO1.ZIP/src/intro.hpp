#ifndef __INTRO_HPP__
#define __INTRO_HPP__

void loadStartScreen();
void displayStartScreen();

#endif //__INTRO_HPP__
